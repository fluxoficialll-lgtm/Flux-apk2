
import { Post, Comment, PaginatedResponse } from '../types';
import { API_BASE } from '../apiConfig';
import { db } from '@/database';
import { authService } from './authService';

const API_URL = `${API_BASE}/api/posts`;

const compressImage = async (file: File, quality = 0.7, maxWidth = 1200): Promise<Blob> => {
    return new Promise((resolve, reject) => {
        if (!file.type.startsWith('image/')) {
            resolve(file); 
            return;
        }

        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(img, 0, 0, width, height);
                canvas.toBlob((blob) => {
                    if (blob) resolve(blob);
                    else reject(new Error('Compression failed'));
                }, 'image/jpeg', quality);
            };
        };
        reader.onerror = (error) => reject(error);
    });
};

const sanitizePost = (post: any): Post => {
    if (!post || typeof post !== 'object') {
        return {
            id: `err_${Date.now()}_${Math.random()}`,
            type: 'text',
            username: 'Sistema',
            text: '',
            time: '',
            timestamp: Date.now(),
            likes: 0,
            comments: 0,
            views: 0,
            isPublic: true,
            liked: false
        };
    }

    const ensureString = (val: any, fallback: string = "") => {
        if (val === null || val === undefined) return fallback;
        return String(val);
    };

    const ensureArray = (val: any) => Array.isArray(val) ? val : [];

    const likedBy = ensureArray(post.likedBy);
    const currentUserEmail = authService.getCurrentUserEmail();

    return {
        ...post,
        id: ensureString(post.id, `temp_${Date.now()}`),
        text: ensureString(post.text, ""), 
        username: ensureString(post.username, "Anônimo"), 
        authorEmail: ensureString(post.authorEmail, post.author_email || ""),
        likes: typeof post.likes === 'number' ? post.likes : 0,
        comments: typeof post.comments === 'number' ? post.comments : 0,
        views: typeof post.views === 'number' ? post.views : 0,
        shares: typeof post.shares === 'number' ? post.shares : 0,
        images: ensureArray(post.images),
        image: ensureString(post.image, undefined),
        video: ensureString(post.video, undefined),
        pollOptions: ensureArray(post.pollOptions),
        commentsList: ensureArray(post.commentsList),
        isAd: !!post.isAd,
        isAdultContent: !!post.isAdultContent,
        likedBy: likedBy,
        liked: currentUserEmail ? likedBy.includes(currentUserEmail) : !!post.liked
    };
};

const formatRelativeTime = (timestamp: number): string => {
    if (!timestamp) return 'Agora';
    const now = Date.now();
    const diff = Math.max(0, now - timestamp); 
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    if (seconds < 60) return 'Agora';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    const date = new Date(timestamp);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
};

export const postService = {
  formatRelativeTime,
  getFeedPaginated: async (options: { limit: number; cursor?: number | string; allowedTypes?: string[]; locationFilter?: string | null; allowAdultContent?: boolean }): Promise<PaginatedResponse<Post>> => {
    try {
        let cursorParam = options.cursor ? `&cursor=${options.cursor}` : '';
        const limitParam = `limit=${options.limit}`;
        if (options.locationFilter && options.locationFilter !== 'Global') {
            cursorParam += `&location=${encodeURIComponent(options.locationFilter)}`;
        }
        const response = await fetch(`${API_URL}?${limitParam}${cursorParam}`);
        if (!response.ok) throw new Error(`Server Error: ${response.status}`);
        const data = await response.json();
        const safePosts = (data.data || []).map(sanitizePost);
        if (safePosts.length > 0) db.posts.saveAll(safePosts);
        return { data: safePosts, nextCursor: data.nextCursor };
    } catch (e) {
        console.warn("API Offline ou Erro, usando cache local:", e);
        let localPosts = db.posts.getAll().map(sanitizePost);
        if (options.locationFilter && options.locationFilter !== 'Global') {
            const filterTerm = options.locationFilter.toLowerCase();
            localPosts = localPosts.filter(p => p.location && p.location.toLowerCase().includes(filterTerm));
        }
        return { data: localPosts.slice(0, options.limit), nextCursor: undefined }; 
    }
  },

  uploadMedia: async (file: File, folder: string = 'feed'): Promise<string> => {
      try {
          const compressedBlob = await compressImage(file);
          const formData = new FormData();
          formData.append('file', compressedBlob, file.name);
          formData.append('folder', folder);
          const response = await fetch(`${API_BASE}/api/upload`, { method: 'POST', body: formData });
          if (response.ok) {
              const data = await response.json();
              if (data.files && data.files.length > 0) return data.files[0].url;
          }
          throw new Error("Erro no upload");
      } catch (e) { throw e; }
  },

  addPost: async (post: Post) => {
    const safePost = sanitizePost(post);
    if (!safePost.authorEmail) {
        const email = authService.getCurrentUserEmail();
        if (email) safePost.authorEmail = email;
    }
    try {
        const response = await fetch(`${API_URL}/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(safePost)
        });
        if (!response.ok) {
            const text = await response.text();
            throw new Error(`Erro do servidor: ${text}`);
        }
        const data = await response.json();
        if (data.success) db.posts.add(sanitizePost(data.post || safePost)); 
    } catch (e) { throw e; }
  },

  toggleLike: async (postId: string) => {
      const post = db.posts.findById(postId);
      const userEmail = authService.getCurrentUserEmail();
      if (post) {
          const isRemoving = post.liked;
          post.liked = !post.liked;
          post.likes += post.liked ? 1 : -1;
          if (userEmail) {
              if (!post.likedBy) post.likedBy = [];
              if (post.liked) post.likedBy.push(userEmail);
              else post.likedBy = post.likedBy.filter(e => e !== userEmail);
          }
          db.posts.update(post);
          fetch(`${API_URL}/${postId}/interact`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ type: 'like', userEmail, action: isRemoving ? 'remove' : 'add' })
          }).catch(() => {});
      }
      return post ? sanitizePost(post) : undefined;
  },

  incrementView: async (id: string, userEmail?: string) => {
      const post = db.posts.findById(id);
      if (post) {
          if (userEmail) {
              if (!post.viewedBy) post.viewedBy = [];
              if (!post.viewedBy.includes(userEmail)) {
                  post.viewedBy.push(userEmail);
                  post.views++;
                  db.posts.update(post);
                  fetch(`${API_URL}/${id}/interact`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'view', userEmail, action: 'add' })
                  }).catch(() => {});
              }
          } else {
              post.views++;
              db.posts.update(post);
              fetch(`${API_URL}/${id}/interact`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'view', userEmail: null, action: 'add' })
              }).catch(() => {});
          }
      }
  },

  incrementShare: async (id: string, userEmail?: string) => {
      const post = db.posts.findById(id);
      if (post) {
          post.shares = (post.shares || 0) + 1;
          db.posts.update(post);
          fetch(`${API_URL}/${id}/interact`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: 'share', userEmail, action: 'add' })
          }).catch(() => {});
      }
  },

  addComment: async (postId: string, text: string, username: string, avatar?: string) => {
      const newComment: Comment = { id: Date.now().toString(), text, username, avatar, timestamp: Date.now(), likes: 0 };
      const post = db.posts.findById(postId);
      if (post) {
          post.commentsList = [newComment, ...(post.commentsList || [])];
          post.comments++;
          db.posts.update(post);
          postService.addPost(post).catch(console.error);
      }
      return newComment;
  },

  deleteComment: async (postId: string, commentId: string) => {
      const post = db.posts.findById(postId);
      if (post && post.commentsList) {
          const recursiveDelete = (comments: Comment[]) => {
              return comments.filter(c => {
                  if (c.id === commentId) return false;
                  if (c.replies) c.replies = recursiveDelete(c.replies);
                  return true;
              });
          };
          post.commentsList = recursiveDelete(post.commentsList);
          post.comments = Math.max(0, (post.comments || 0) - 1);
          db.posts.update(post);
          try {
              await fetch(`${API_URL}/${postId}/comments/${commentId}`, { method: 'DELETE' });
          } catch (e) { console.error("Failed to delete comment on server", e); }
          return true;
      }
      return false;
  },

  getPostById: (id: string) => {
      const post = db.posts.findById(id);
      return post ? sanitizePost(post) : undefined;
  },

  getUserPosts: (username: string) => {
      const posts = db.posts.getAll().filter(p => p.username === username);
      return posts.map(sanitizePost);
  },

  deletePost: async (id: string) => {
      db.posts.delete(id);
      try {
          const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
          if (!response.ok) {
              const data = await response.json().catch(() => ({}));
              throw new Error(data.error || "Falha na exclusão remota");
          }
      } catch (e) { throw e; }
  },

  addReply: (postId: string, commentId: string, text: string, username: string, avatar?: string): Comment | undefined => {
      const post = db.posts.findById(postId);
      if (post && post.commentsList) {
          const newReply: Comment = { id: Date.now().toString(), text, username, avatar, timestamp: Date.now(), likes: 0 };
          const addReplyRecursive = (comments: Comment[]): boolean => {
              for (const comment of comments) {
                  if (comment.id === commentId) {
                      comment.replies = [...(comment.replies || []), newReply];
                      return true;
                  }
                  if (comment.replies && addReplyRecursive(comment.replies)) return true;
              }
              return false;
          };
          if (addReplyRecursive(post.commentsList)) {
              post.comments++;
              db.posts.update(post);
              postService.addPost(post).catch(console.error);
              return newReply;
          }
      }
      return undefined;
  },

  toggleCommentLike: (postId: string, commentId: string): boolean => {
      const post = db.posts.findById(postId);
      if (post && post.commentsList) {
          const toggleRecursive = (comments: Comment[]): boolean => {
              for (const comment of comments) {
                  if (comment.id === commentId) {
                      comment.likedByMe = !comment.likedByMe;
                      comment.likes = (comment.likes || 0) + (comment.likedByMe ? 1 : -1);
                      return true;
                  }
                  if (comment.replies && toggleRecursive(comment.replies)) return true;
              }
              return false;
          };
          if (toggleRecursive(post.commentsList)) {
              db.posts.update(post);
              postService.addPost(post).catch(console.error);
              return true;
          }
      }
      return false;
  }
};
