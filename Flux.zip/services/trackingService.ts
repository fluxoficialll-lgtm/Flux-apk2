/**
 * Service to handle UTM Tracking and Attribution
 * Captures parameters from URL (HashRouter compatible) and persists them.
 */

export interface TrackingParams {
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
    utm_term?: string;
    utm_content?: string;
    src?: string; // Common shorthand
    ref?: string; // Affiliate Reference
    [key: string]: string | undefined;
}

const STORAGE_KEY = 'flux_attribution_data';
const AFFILIATE_KEY = 'affiliate_ref'; 
const EXPIRATION_DAYS = 30; // Attribution window

export const trackingService = {
    /**
     * Captures UTM parameters from the entire URL string.
     * Supports standard query params, hash params, and deep links.
     */
    captureUrlParams: () => {
        try {
            const currentParams = trackingService.getStoredParams() || {};
            let hasNewParams = false;

            // Use a unified approach to extract params from the full URL
            // This handles cases where ?ref= is before OR after the # fragment
            const fullUrl = window.location.href;
            const urlParts = fullUrl.split(/[?&]/);
            
            const trackableKeys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'src', 'ref'];

            urlParts.forEach(part => {
                const [key, value] = part.split('=');
                if (key && value && trackableKeys.includes(key)) {
                    const decodedValue = decodeURIComponent(value.split('#')[0]); // Clean up any trailing hash fragments
                    
                    // Normalização CRÍTICA: Lowercase e trim
                    const normalizedValue = decodedValue.toLowerCase().trim();
                    
                    if (currentParams[key] !== normalizedValue) {
                        currentParams[key] = normalizedValue;
                        hasNewParams = true;

                        // Persistência prioritária para o afiliado (ref)
                        if (key === 'ref' && normalizedValue) {
                            localStorage.setItem(AFFILIATE_KEY, normalizedValue);
                            console.log(`🎯 [Tracking] AFILIADO IDENTIFICADO: ${normalizedValue}`);
                        }
                    }
                }
            });

            if (hasNewParams) {
                const payload = {
                    params: currentParams,
                    timestamp: Date.now()
                };
                localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
            }

        } catch (e) {
            console.error("[Tracking] Error capturing params", e);
        }
    },

    /**
     * Retrieves valid stored parameters.
     */
    getStoredParams: (): TrackingParams => {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return {};

            const data = JSON.parse(raw);
            const now = Date.now();
            const daysDiff = (now - data.timestamp) / (1000 * 60 * 60 * 24);
            
            if (daysDiff > EXPIRATION_DAYS) {
                localStorage.removeItem(STORAGE_KEY);
                return {};
            }

            return data.params || {};
        } catch (e) {
            return {};
        }
    },

    /**
     * Returns the persistent affiliate reference.
     * Ensures consistent casing and trimming.
     */
    getAffiliateRef: (): string | null => {
        const ref = localStorage.getItem(AFFILIATE_KEY);
        return ref ? ref.toLowerCase().trim() : null;
    },

    /**
     * Generates a link with tracking parameters.
     */
    generateTrackingLink: (baseUrl: string, params: TrackingParams): string => {
        const query = new URLSearchParams();
        Object.entries(params).forEach(([key, value]) => {
            if (value) {
                query.set(key, value.toLowerCase().trim());
            }
        });

        const queryString = query.toString();
        if (!queryString) return baseUrl;

        const separator = baseUrl.includes('?') ? '&' : '?';
        return `${baseUrl}${separator}${queryString}`;
    },

    /**
     * Clears tracking data but keeps the affiliate link for the session if needed.
     * Usually called after successful conversion.
     */
    clear: () => {
        localStorage.removeItem(STORAGE_KEY);
        // Note: We often keep AFFILIATE_KEY until logout or actual conversion is fully processed
    },
    
    /**
     * Hard clear of all tracking identifiers.
     */
    hardReset: () => {
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem(AFFILIATE_KEY);
    }
};