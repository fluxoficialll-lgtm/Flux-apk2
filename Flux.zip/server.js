
import 'dotenv/config';
import express from 'express';
import path from 'path';
import cors from 'cors';
import compression from 'compression';
import helmet from 'helmet';
import multer from 'multer';
import fs from 'fs';
import http from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dbManager } from './backend/databaseManager.js';
import { storageService } from './backend/services/storageService.js';
import apiRoutes from './backend/routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Priority: Use the PORT provided by Render
const PORT = process.env.PORT || 3000;
const httpServer = http.createServer(app);

const io = new Server(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] }
});

io.on('connection', (socket) => {
    socket.on('join_user', (email) => socket.join(email));
    socket.on('join_chat', (chatId) => socket.join(chatId));
});

app.set('trust proxy', 1);

const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 50 * 1024 * 1024 } 
});

app.use(helmet({
  contentSecurityPolicy: false, 
  crossOriginEmbedderPolicy: false,
  crossOriginOpenerPolicy: { policy: "same-origin-allow-popups" },
  referrerPolicy: { policy: "strict-origin-when-cross-origin" }
}));
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '50mb' })); 
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.use((req, res, next) => {
    req.io = io;
    next();
});

// Start DB Initialization before listening
dbManager.init()
    .then(() => {
        console.log("✅ Database initialized successfully.");
    })
    .catch(err => {
        console.error("❌ DB Init Error:", err);
    });

// Rota de Upload com suporte a pastas dinâmicas
app.post('/api/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }
    
    try {
        const folder = req.body.folder || 'misc';
        console.log(`📤 Enviando arquivo para pasta [${folder}] no R2...`);
        const fileUrl = await storageService.uploadFile(req.file, folder);
        
        res.json({ 
            success: true, 
            files: [{ url: fileUrl }] 
        });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao processar upload para nuvem' });
    }
});

app.use('/api', apiRoutes);
app.get('/ping', (req, res) => res.send('pong'));

app.use(express.static(path.join(__dirname, 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Render requirement: listen on all interfaces (0.0.0.0)
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}. Mode: ${process.env.NODE_ENV || 'development'}`);
});
