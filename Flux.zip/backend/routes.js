
import express from 'express';
import axios from 'axios';
import crypto from 'crypto';
import { dbManager } from './databaseManager.js';
import { facebookCapi } from './services/facebookCapi.js'; 
import { storageService } from './services/storageService.js';

const router = express.Router();

const RAW_PAYMENT_URL = process.env.PAYMENT_API_URL || 'https://api.syncpayments.com.br';
const PAYMENT_API_URL = RAW_PAYMENT_URL.replace(/\/v1\/?$/, '').replace(/\/$/, '');

const AXIOS_CONFIG = {
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) FluxPlatform/1.0'
    },
    timeout: 20000 
};

/**
 * Helper para apagar arquivo apenas se for a última referência.
 */
const safeStorageDelete = async (url) => {
    if (!url || typeof url !== 'string') return;
    try {
        const refs = await dbManager.countMediaReferences(url);
        // Se refs <= 1, significa que apenas este objeto que estamos deletando o referencia
        if (refs <= 1) {
            console.log(`🗑️ [Storage Cleanup] Última referência encontrada para: ${url}. Excluindo...`);
            await storageService.deleteFile(url);
        } else {
            console.log(`🛡️ [Storage Cleanup] ${refs} referências mantidas para: ${url}. Ignorando exclusão física.`);
        }
    } catch (e) {
        console.error("Error in safeStorageDelete:", e.message);
    }
};

// --- HELPER PARA DISPARO DE PIXEL DE AFILIADO (CAPI) ---
const triggerAffiliateCapi = async (referredBy, eventName, buyerEmail, eventData = {}) => {
    if (!referredBy) return;
    
    try {
        const affiliate = await dbManager.users.findByEmail(referredBy.toLowerCase().trim());
        if (affiliate && affiliate.marketingConfig?.pixelId && affiliate.marketingConfig?.pixelToken) {
            console.log(`📡 [CAPI Afiliado] Disparando ${eventName} para o pixel de ${referredBy}`);
            
            await facebookCapi.sendEvent({
                pixelId: affiliate.marketingConfig.pixelId,
                accessToken: affiliate.marketingConfig.pixelToken,
                eventName: eventName,
                eventId: `${eventName.toLowerCase()}_${referredBy}_${buyerEmail}_${Date.now()}`,
                userData: {
                    email: buyerEmail,
                    externalId: [buyerEmail],
                    actionSource: 'website'
                },
                eventData: eventData,
                url: 'https://flux.com/onboarding'
            });
        }
    } catch (e) {
        console.error(`[CAPI Afiliado Error] ${eventName}:`, e.message);
    }
};

// --- ROTA DE MÉTRICAS (INTERAÇÕES) ---
router.post('/posts/:id/interact', async (req, res) => {
    try {
        const { id } = req.params;
        const { type, userEmail, action } = req.body; 
        
        if (action === 'remove' && type === 'like') {
            await dbManager.interactions.remove(id, userEmail, type);
        } else {
            await dbManager.interactions.record(id, userEmail, type);
        }
        
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/tracking/pixel-info', async (req, res) => {
    try {
        const { ref } = req.query;
        if (!ref) return res.status(400).json({ error: "Ref missing" });
        
        const affiliate = await dbManager.users.findByEmail(ref.toLowerCase().trim());
        if (affiliate && affiliate.marketingConfig?.pixelId) {
            return res.json({ pixelId: affiliate.marketingConfig.pixelId });
        }
        res.status(404).json({ error: "No pixel configured" });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/rankings/top', async (req, res) => {
    try {
        const topCreators = await dbManager.relationships.getTopCreators();
        res.json({ data: topCreators });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/groups/ranking', async (req, res) => {
    try { 
        const groups = await dbManager.groups.list();
        groups.sort((a, b) => (b.members?.length || 0) - (a.members?.length || 0));
        res.json({ data: groups }); 
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/affiliates/stats', async (req, res) => {
    try {
        const { email } = req.query;
        if (!email) return res.status(400).json({ error: "Email não fornecido" });

        const normalizedEmail = email.toLowerCase().trim();
        const stats = await dbManager.affiliates.getStats(normalizedEmail);
        
        const enrichedSellers = await Promise.all(stats.sellersList.map(async (s) => {
            const user = await dbManager.users.findByEmail(s.email);
            const emailPrefix = s.email.split('@')[0];
            
            return {
                ...s,
                name: user?.profile?.nickname || user?.profile?.name || `Novo Usuário (${emailPrefix})`,
                username: user?.profile?.name || emailPrefix,
                avatar: user?.profile?.photoUrl || ''
            };
        }));

        enrichedSellers.sort((a, b) => {
            if (b.totalGenerated !== a.totalGenerated) return b.totalGenerated - a.totalGenerated;
            return a.email.localeCompare(b.email);
        });

        res.json({
            totalEarned: stats.totalEarned,
            referredSellers: enrichedSellers,
            recentSales: stats.earnings.map(e => ({
                id: e.sale_id,
                buyerEmail: e.data?.buyerEmail || 'Oculto',
                amount: e.data?.fullAmount || 0,
                commission: e.amount,
                timestamp: new Date(e.created_at).getTime(),
                sellerName: e.data?.sellerName || e.seller_email
            }))
        });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/syncpay/check-status', async (req, res) => {
    try {
        const { transactionId, sellerEmail, clientId, clientSecret, groupId, buyerEmail, tracking } = req.body;
        
        let finalClientId = clientId;
        let finalClientSecret = clientSecret;

        const normalizedSeller = sellerEmail ? sellerEmail.toLowerCase().trim() : null;
        const normalizedBuyer = buyerEmail ? buyerEmail.toLowerCase().trim() : null;

        if (!finalClientId || !finalClientSecret) {
            if (normalizedSeller) {
                const owner = await dbManager.users.findByEmail(normalizedSeller);
                if (owner && owner.paymentConfig) {
                    finalClientId = owner.paymentConfig.clientId;
                    finalClientSecret = owner.paymentConfig.clientSecret;
                }
            }
        }

        if (!finalClientId || !finalClientSecret) return res.json({ status: 'unknown' });
        
        const authUrl = `${PAYMENT_API_URL}/api/partner/v1/auth-token`;
        const authResponse = await axios.post(authUrl, { client_id: finalClientId, client_secret: finalClientSecret }, AXIOS_CONFIG);
        const token = authResponse.data.access_token;

        const checkUrl = `${PAYMENT_API_URL}/api/partner/v1/transaction/${transactionId}`;
        const response = await axios.get(checkUrl, {
            headers: { 'Authorization': `Bearer ${token}`, ...AXIOS_CONFIG.headers }
        });

        const status = response.data.data ? response.data.data.status : 'unknown';
        
        if ((status === 'paid' || status === 'completed') && groupId && normalizedBuyer) {
            const existingAccess = await dbManager.vipAccess.get(normalizedBuyer, groupId);
            
            if (!existingAccess || existingAccess.status !== 'active') {
                const group = await dbManager.groups.getById(groupId);
                let expiresAt = undefined;
                if (group && group.accessType === 'temporary' && group.expirationDate) {
                    const days = parseInt(group.expirationDate); 
                    if (!isNaN(days)) expiresAt = Date.now() + (days * 24 * 60 * 60 * 1000);
                }

                await dbManager.vipAccess.grant({
                    userId: normalizedBuyer,
                    groupId: groupId,
                    status: 'active',
                    purchaseDate: Date.now(),
                    expiresAt: expiresAt,
                    transactionId: transactionId
                });

                const seller = await dbManager.users.findByEmail(normalizedSeller);
                if (seller && seller.referredBy) {
                    await dbManager.affiliates.recordEarning(
                        seller.referredBy, 
                        normalizedSeller, 
                        1.00, 
                        transactionId,
                        { buyerEmail: normalizedBuyer, sellerName: seller.profile?.name, fullAmount: group.price }
                    );
                }

                if (group && group.pixelId && group.pixelToken) {
                    try {
                        await facebookCapi.sendEvent({
                            pixelId: group.pixelId,
                            accessToken: group.pixelToken,
                            eventName: 'Purchase',
                            eventId: `purch_${transactionId}`,
                            userData: {
                                email: normalizedBuyer,
                                fbp: tracking?.fbp,
                                fbc: tracking?.fbc,
                                client_ip_address: req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress,
                                actionSource: 'website',
                                externalId: [normalizedBuyer]
                            },
                            eventData: {
                                currency: group.currency || 'BRL',
                                value: parseFloat(group.price || '0'),
                                content_name: group.name,
                                content_type: 'product_group',
                                content_ids: [groupId],
                                order_id: transactionId
                            },
                            url: 'https://flux.com/checkout',
                            testEventCode: tracking?.testEventCode
                        });
                    } catch (capiError) { console.error(`CAPI Error: ${capiError.message}`); }
                }
            }
        }
        res.json({ status: status });
    } catch (error) {
        console.error("Check Status Error:", error);
        res.status(500).json({ status: 'unknown' });
    }
});

router.post('/auth/register', async (req, res) => {
    try {
        const user = req.body; 
        if (user.email) user.email = user.email.toLowerCase().trim();
        if (user.referredBy) user.referredBy = user.referredBy.toLowerCase().trim();
        
        await dbManager.users.create(user);
        
        if (user.referredBy) {
            await triggerAffiliateCapi(user.referredBy, 'Lead', user.email);
        }

        res.json({ success: true, user });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const normalizedEmail = email.toLowerCase().trim();
        const user = await dbManager.users.findByEmail(normalizedEmail);
        if (user && user.password === password) { 
             res.json({ user, token: 'mock_token_' + Date.now() });
        } else {
             res.status(401).json({ error: 'Credenciais inválidas' });
        }
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/auth/google', async (req, res) => {
    try {
        const { googleToken, referredBy } = req.body;
        let email = "usuario_google@gmail.com";
        let name = "Usuário Google";
        let picture = "";
        
        if (googleToken && googleToken.split('.').length === 3) {
            try {
                const payload = JSON.parse(Buffer.from(googleToken.split('.')[1], 'base64').toString());
                email = (payload.email || email).toLowerCase().trim();
                name = payload.name || name;
                picture = payload.picture || "";
            } catch (e) {}
        }
        
        let user = await dbManager.users.findByEmail(email);
        let isNew = false;
        const finalRef = referredBy ? referredBy.toLowerCase().trim() : null;

        if (!user) {
            isNew = true;
            user = {
                email,
                password: "google_auth_" + Date.now(),
                isVerified: true,
                isProfileCompleted: false,
                referredBy: finalRef, 
                profile: {
                    name: email.split('@')[0].replace(/[^a-z0-9]/g, ''),
                    nickname: name,
                    photoUrl: picture,
                    isPrivate: false
                }
            };
            await dbManager.users.create(user);
            
            if (finalRef) {
                await triggerAffiliateCapi(finalRef, 'Lead', email);
            }
        }
        
        res.json({ user, token: 'google_session_' + Date.now(), isNew });
    } catch (e) { 
        console.error("Google Auth Error:", e);
        res.status(500).json({ error: e.message }); 
    }
});

router.get('/users/sync', async (req, res) => {
    try { const users = await dbManager.users.getAll(); res.json({ users }); } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/users/update', async (req, res) => {
    try {
        const { email, updates } = req.body;
        const normalizedEmail = email.toLowerCase().trim();
        const user = await dbManager.users.findByEmail(normalizedEmail);
        
        if (user) {
            // Se estiver alterando o avatar, tenta remover o antigo respeitando referências
            if (updates.profile?.photoUrl && user.profile?.photoUrl && updates.profile.photoUrl !== user.profile.photoUrl) {
                await safeStorageDelete(user.profile.photoUrl);
            }

            const currentProfile = user.profile || {};
            const newProfile = updates.profile ? { ...currentProfile, ...updates.profile } : currentProfile;
            
            const wasJustCompleted = !user.isProfileCompleted && updates.isProfileCompleted === true;

            const updatedUser = { ...user, ...updates, profile: newProfile };
            await dbManager.users.update(updatedUser);

            if (wasJustCompleted && user.referredBy) {
                await triggerAffiliateCapi(user.referredBy, 'CompleteRegistration', normalizedEmail);
            }

            res.json({ user: updatedUser });
        } else res.status(404).json({ error: 'User not found' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/users/search', async (req, res) => {
    try {
        const query = req.query.q ? String(req.query.q).toLowerCase() : '';
        const allUsers = await dbManager.users.getAll();
        const results = allUsers.filter(u => {
            const name = u.profile?.name?.toLowerCase() || '';
            const nickname = u.profile?.nickname?.toLowerCase() || '';
            return name.includes(query) || nickname.includes(query);
        });
        res.json(results);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/groups', async (req, res) => {
    try {
        const { email } = req.query;
        let groups;
        if (email) {
            const normalizedEmail = email.toLowerCase().trim();
            groups = await dbManager.groups.listForUser(normalizedEmail);
        } else {
            groups = await dbManager.groups.list();
        }
        res.json({ data: groups });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/groups/:id', async (req, res) => {
    try {
        const group = await dbManager.groups.getById(req.params.id);
        if (group) {
            let isPaymentActive = false;
            if (group.creatorEmail) {
                const normalizedCreator = group.creatorEmail.toLowerCase().trim();
                const creator = await dbManager.users.findByEmail(normalizedCreator);
                if (creator && creator.paymentConfig && creator.paymentConfig.isConnected) isPaymentActive = true;
            }
            if (group.status === 'inactive') isPaymentActive = false;
            res.json({ group: { ...group, isPaymentActive } });
        } else res.status(404).json({ error: 'Group not found' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/groups/create', async (req, res) => {
    try { 
        const group = req.body;
        const normalizedCreator = group.creatorEmail ? group.creatorEmail.toLowerCase().trim() : null;
        if (normalizedCreator) group.creatorEmail = normalizedCreator;
        
        await dbManager.groups.create(group); 
        
        if (normalizedCreator) {
            const creator = await dbManager.users.findByEmail(normalizedCreator);
            if (creator && creator.referredBy) {
                const myGroups = await dbManager.groups.listForUser(normalizedCreator);
                if (myGroups.length <= 1) {
                    await triggerAffiliateCapi(creator.referredBy, 'StartTrial', normalizedCreator);
                }
            }
        }

        res.json({ success: true }); 
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/groups/:id', async (req, res) => {
    try { 
        const group = req.body;
        if (group.creatorEmail) group.creatorEmail = group.creatorEmail.toLowerCase().trim();
        await dbManager.groups.create(group); 
        res.json({ success: true }); 
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// --- EXCLUSÃO RECURSIVA COM CLEANUP DE STORAGE (GRUPOS + CHATS) ---
router.delete('/groups/:id', async (req, res) => {
    try {
        const groupId = req.params.id;
        const group = await dbManager.groups.getById(groupId);
        
        if (group) {
            console.log(`🧹 [Group Cleanup] Iniciando limpeza total do grupo: ${group.name} (${groupId})`);
            
            // 1. Limpa capa do grupo (Pode estar em avatars se for VIP, ou misc)
            if (group.coverImage) {
                await safeStorageDelete(group.coverImage);
            }
            
            // 2. Limpa mídias da Porta VIP (Diretório vips_doors conforme especificação)
            if (group.vipDoor?.mediaItems) {
                for (const item of group.vipDoor.mediaItems) {
                    await safeStorageDelete(item.url);
                }
            }
            
            // 3. Limpa todas as mídias enviadas no chat deste grupo
            const chat = await dbManager.chats.get(groupId);
            if (chat && chat.messages) {
                console.log(`💬 [Group Cleanup] Analisando ${chat.messages.length} mensagens para remoção de mídias...`);
                for (const msg of chat.messages) {
                    if (msg.mediaUrl) {
                        await safeStorageDelete(msg.mediaUrl);
                    }
                }
            }
        }

        // 4. Remove dos registros do Banco de Dados
        await dbManager.groups.delete(groupId);
        
        // Remove o chat associado também
        try {
            await dbManager.query("DELETE FROM chats WHERE id = $1", [groupId]);
        } catch (chatDelErr) {
            console.warn(`[Group Cleanup] Aviso: Chat ${groupId} não pôde ser removido ou não existia.`);
        }

        res.json({ success: true });
    } catch (e) { 
        console.error("❌ [Group Delete Error]:", e.message);
        res.status(500).json({ error: e.message }); 
    }
});

router.get('/chats/sync', async (req, res) => { 
    try {
        const { email } = req.query;
        if (!email) return res.status(400).json({ error: 'Email missing' });
        const chats = await dbManager.chats.listForUser(email);
        res.json({ chats });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

router.post('/chats/send', async (req, res) => {
    try {
        const { chatId, message } = req.body;
        let chat = await dbManager.chats.get(chatId);
        if (!chat) chat = { id: chatId, contactName: 'Chat', isBlocked: false, messages: [] };
        chat.messages.push(message);
        await dbManager.chats.save(chat);
        if (req.io) req.io.to(chatId).emit('new_message', { chatId, message });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/chats/delete-messages', async (req, res) => {
    try {
        const { chatId, messageIds, mode, userEmail } = req.body;
        if (!chatId || !messageIds || !Array.isArray(messageIds) || !userEmail) return res.status(400).json({ error: 'Dados incompletos' });
        const normalizedEmail = userEmail.toLowerCase().trim();
        let chat = await dbManager.chats.get(chatId);
        if (!chat) return res.status(404).json({ error: 'Chat não encontrado' });
        let updated = false;
        
        for (const msg of chat.messages) {
            if (messageIds.includes(msg.id)) {
                // Se deletar para todos, tenta limpar o arquivo pesado do storage respeitando referências
                if (mode === 'all' && msg.senderEmail === normalizedEmail) {
                    if (msg.mediaUrl) await safeStorageDelete(msg.mediaUrl);
                }
            }
        }

        chat.messages = chat.messages.map(msg => {
            if (messageIds.includes(msg.id)) {
                if (mode === 'all') {
                    if (msg.senderEmail === normalizedEmail) {
                        updated = true;
                        return { ...msg, text: '🚫 Esta mensagem foi apagada.', contentType: 'text', mediaUrl: undefined, product: undefined, isDeleted: true };
                    }
                } else if (mode === 'me') {
                    updated = true;
                    const hiddenFor = msg.hiddenFor || [];
                    if (!hiddenFor.includes(normalizedEmail)) return { ...msg, hiddenFor: [...hiddenFor, normalizedEmail] };
                }
            }
            return msg;
        });
        if (updated) {
            await dbManager.chats.save(chat);
            if (req.io) req.io.to(chatId).emit('messages_deleted', { chatId, messageIds, mode, deleterEmail: normalizedEmail });
        }
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/chats/:id', async (req, res) => {
    try {
        const chat = await dbManager.chats.get(req.params.id);
        if (!chat) return res.json({ data: [] });
        let messages = chat.messages || [];
        const limit = parseInt(req.query.limit) || 50;
        const beforeId = req.query.before ? parseInt(req.query.before) : null;
        messages.sort((a, b) => b.id - a.id); 
        let startIndex = 0;
        if (beforeId) {
            const index = messages.findIndex(m => m.id < beforeId);
            if (index === -1) return res.json({ data: [] });
            startIndex = index;
        }
        const sliced = messages.slice(startIndex, startIndex + limit);
        res.json({ data: sliced.reverse() });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/posts', async (req, res) => {
    try { 
        const limit = req.query.limit ? parseInt(req.query.limit) : 50; 
        
        // Sanitize cursor input
        let cursor = req.query.cursor || null;
        if (cursor === 'null' || cursor === 'undefined' || cursor === '') {
            cursor = null;
        }
        
        const posts = await dbManager.posts.list(limit, cursor); 
        const nextCursor = posts.length > 0 ? posts[posts.length - 1].timestamp : null;
        res.json({ data: posts, nextCursor }); 
    } catch (e) { res.status(500).json({ error: e.message }); }
});
router.post('/posts/create', async (req, res) => {
    try { await dbManager.posts.create(req.body); res.json({ success: true, post: req.body }); } catch (e) { res.status(500).json({ error: e.message }); }
});

// --- EXCLUSÃO COM CLEANUP DE STORAGE (POSTS / REELS) ---
router.delete('/posts/:id', async (req, res) => {
    try {
        const post = await dbManager.posts.getById(req.params.id);
        if (post) {
            // Remove mídias respeitando referências
            if (post.image) await safeStorageDelete(post.image);
            if (post.video) await safeStorageDelete(post.video);
            if (post.images && Array.isArray(post.images)) {
                for (const img of post.images) {
                    await safeStorageDelete(img);
                }
            }
        }
        await dbManager.posts.delete(req.params.id);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// --- EXCLUSÃO DE COMENTÁRIO EM POST ---
router.delete('/posts/:id/comments/:commentId', async (req, res) => {
    try {
        const { id, commentId } = req.params;
        const post = await dbManager.posts.getById(id);
        if (post && post.commentsList) {
            const recursiveDelete = (comments) => {
                return comments.filter(c => {
                    if (c.id === commentId) return false;
                    if (c.replies) c.replies = recursiveDelete(c.replies);
                    return true;
                });
            };
            post.commentsList = recursiveDelete(post.commentsList);
            post.comments = Math.max(0, (post.comments || 0) - 1);
            await dbManager.posts.create(post);
            res.json({ success: true });
        } else res.status(404).json({ error: 'Post not found' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/marketplace', async (req, res) => { try { const items = await dbManager.marketplace.list(); res.json({ data: items }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.post('/marketplace/create', async (req, res) => { try { await dbManager.marketplace.create(req.body); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); } });

// --- EXCLUSÃO COM CLEANUP DE STORAGE (MARKETPLACE) ---
router.delete('/marketplace/:id', async (req, res) => {
    try {
        const item = await dbManager.marketplace.getById(req.params.id);
        if (item) {
            if (item.image) await safeStorageDelete(item.image);
            if (item.video) await safeStorageDelete(item.video);
            if (item.images && Array.isArray(item.images)) {
                for (const img of item.images) {
                    await safeStorageDelete(img);
                }
            }
        }
        await dbManager.marketplace.delete(req.params.id);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// --- EXCLUSÃO DE COMENTÁRIO EM MARKETPLACE ---
router.delete('/marketplace/:id/comments/:commentId', async (req, res) => {
    try {
        const { id, commentId } = req.params;
        const item = await dbManager.marketplace.getById(id);
        if (item && item.comments) {
            item.comments = item.comments.filter(c => c.id !== commentId);
            await dbManager.marketplace.create(item);
            res.json({ success: true });
        } else res.status(404).json({ error: 'Item not found' });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/ads', async (req, res) => { try { const ads = await dbManager.ads.list(); res.json({ data: ads }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.post('/ads/create', async (req, res) => { try { await dbManager.ads.create(req.body); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.delete('/ads/:id', async (req, res) => {
    try {
        const ads = await dbManager.ads.list();
        const ad = ads.find(a => a.id === req.params.id);
        if (ad && ad.creative?.mediaUrl) {
            await safeStorageDelete(ad.creative.mediaUrl);
        }
        await dbManager.ads.delete(req.params.id);
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/relationships', async (req, res) => { try { const rels = await dbManager.relationships.list(); res.json({ data: rels }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.post('/relationships/follow', async (req, res) => { try { await dbManager.relationships.create(req.body); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.post('/relationships/unfollow', async (req, res) => { try { const { followerEmail, followingUsername } = req.body; await dbManager.relationships.delete(followerEmail, followingUsername); res.json({ success: true }); } catch (e) { res.status(500).json({ error: e.message }); } });
router.post('/moderation/analyze', (req, res) => { res.json({ isAdult: false }); });
router.post('/device/register', (req, res) => { res.json({ success: true }); });
router.post('/send-email', (req, res) => { res.json({ success: true }); });

router.post('/syncpay/auth-token', async (req, res) => {
    try {
        const { clientId, clientSecret } = req.body;
        const targetUrl = `${PAYMENT_API_URL}/api/partner/v1/auth-token`;
        const response = await axios.post(targetUrl, { client_id: clientId, client_secret: clientSecret }, AXIOS_CONFIG);
        res.json(response.data);
    } catch (error) { res.status(error.response?.status || 502).json(error.response?.data || { error: 'Falha SyncPay' }); }
});

router.post('/syncpay/cash-in', async (req, res) => {
    try {
        const { groupId, ownerEmail, payload, tracking } = req.body;
        let creatorEmail = ownerEmail;
        if (groupId) { const group = await dbManager.groups.getById(groupId); if (group && !creatorEmail) creatorEmail = group.creatorEmail; }
        if (!creatorEmail) return res.status(400).json({ error: "Proprietário não identificado." });
        const normalizedCreator = creatorEmail.toLowerCase().trim();
        const owner = await dbManager.users.findByEmail(normalizedCreator);
        if (!owner || !owner.paymentConfig || !owner.paymentConfig.isConnected) return res.status(400).json({ error: "Vendedor não configurado." });
        const { clientId, clientSecret } = owner.paymentConfig;
        const authUrl = `${PAYMENT_API_URL}/api/partner/v1/auth-token`;
        const authResponse = await axios.post(authUrl, { client_id: clientId, client_secret: clientSecret }, AXIOS_CONFIG);
        const token = authResponse.data.access_token;
        const cashInUrl = `${PAYMENT_API_URL}/api/partner/v1/cash-in`;
        const response = await axios.post(cashInUrl, payload, { headers: { 'Authorization': `Bearer ${token}`, ...AXIOS_CONFIG.headers } });
        const rData = response.data;
        const pixCode = rData.pix_code || rData.qrcode || rData.data?.pix_code || "";
        const identifier = rData.identifier || rData.transaction_id || rData.data?.identifier || "";
        const qrCodeImage = rData.qr_code_base64 || rData.data?.qr_code_base64 || "";
        res.json({ pixCode, identifier, qrCodeImage });
    } catch (error) { res.status(500).json({ error: "Erro ao gerar PIX" }); }
});

router.post('/syncpay/balance', async (req, res) => {
    try {
        const { clientId, clientSecret } = req.body;
        const authUrl = `${PAYMENT_API_URL}/api/partner/v1/auth-token`;
        const authRes = await axios.post(authUrl, { client_id: clientId, client_secret: clientSecret }, AXIOS_CONFIG);
        const token = authRes.data.access_token;
        const balUrl = `${PAYMENT_API_URL}/api/partner/v1/balance`;
        const response = await axios.get(balUrl, { headers: { 'Authorization': `Bearer ${token}`, ...AXIOS_CONFIG.headers } });
        res.json({ balance: response.data.balance || 0 });
    } catch (error) { res.status(500).json({ balance: 0 }); }
});

router.post('/syncpay/transactions', async (req, res) => { res.json([]); });

router.post('/syncpay/withdraw', async (req, res) => {
    try {
        const { email, clientId, clientSecret, amount, pixKey, pixKeyType } = req.body;
        
        if (!email || !clientId || !clientSecret || !amount || !pixKey) {
            return res.status(400).json({ error: "Dados incompletos para o saque." });
        }

        const normalizedEmail = email.toLowerCase().trim();

        const authUrl = `${PAYMENT_API_URL}/api/partner/v1/auth-token`;
        const authResponse = await axios.post(authUrl, { client_id: clientId, client_secret: clientSecret }, AXIOS_CONFIG);
        const token = authResponse.data.access_token;

        const balUrl = `${PAYMENT_API_URL}/api/partner/v1/balance`;
        const balanceResponse = await axios.get(balUrl, { headers: { 'Authorization': `Bearer ${token}`, ...AXIOS_CONFIG.headers } });
        const currentBalance = balanceResponse.data.balance || 0;

        if (amount > currentBalance) {
            return res.status(400).json({ error: "Saldo insuficiente para saque de produção." });
        }

        const withdrawUrl = `${PAYMENT_API_URL}/api/partner/v1/cash-out`;
        
        const payload = {
            amount: Number(amount),
            pix_key: pixKey,
            pix_key_type: pixKeyType || 'CPF',
            description: `SAQUE FLUX PRODUCTION: ${normalizedEmail}`
        };

        const response = await axios.post(withdrawUrl, payload, { 
            headers: { 'Authorization': `Bearer ${token}`, ...AXIOS_CONFIG.headers } 
        });

        const txData = response.data;
        const providerTxId = txData.identifier || txData.id || txData.transaction_id || `TX_WD_${Date.now()}`;

        await dbManager.transactions.record(
            normalizedEmail, 
            'withdrawal', 
            amount, 
            'completed', 
            providerTxId, 
            { pixKey, pixKeyType, rawResponse: txData }
        );

        console.log(`🏦 [PROD WITHDRAWAL] Confirmed for ${normalizedEmail}: R$ ${amount}. ID: ${providerTxId}`);
        
        res.json({ 
            success: true, 
            message: "Saque realizado com sucesso em ambiente de produção.",
            transactionId: providerTxId
        });

    } catch (error) {
        const errorData = error.response?.data || {};
        console.error("❌ [PROD WITHDRAWAL ERROR]:", errorData.message || error.message);
        
        if (req.body.email) {
            const normalizedEmail = req.body.email.toLowerCase().trim();
            await dbManager.transactions.record(
                normalizedEmail, 
                'withdrawal', 
                req.body.amount, 
                'failed', 
                'NONE', 
                { error: errorData.message || error.message }
            ).catch(() => {});
        }

        res.status(500).json({ 
            error: "Falha crítica no saque de produção. Verifique saldo e chaves.",
            details: errorData.message || "Timeout ou erro de rede no provedor."
        });
    }
});

router.post('/tracking/capi', async (req, res) => {
    const { pixelId, eventName, eventData, userData, eventId, url, testEventCode, groupId } = req.body;
    let accessToken = null;
    let resolvedPixelId = pixelId;
    if (groupId) {
        try {
            const group = await dbManager.groups.getById(groupId);
            if (!group) return res.status(422).json({ error: 'INVALID_GROUP_CONTEXT' });
            if (group.pixelToken) accessToken = group.pixelToken;
            if (group.pixelId) resolvedPixelId = group.pixelId;
        } catch(e) { return res.status(500).json({ error: 'DB_LOOKUP_FAILED' }); }
    } else if (resolvedPixelId) {
        try { const matchingGroup = await dbManager.groups.findByPixelId(resolvedPixelId); if (matchingGroup && matchingGroup.pixelToken) accessToken = matchingGroup.pixelToken; } catch(e) {}
    }
    if (!accessToken && req.body.accessToken) accessToken = req.body.accessToken;
    if (!accessToken) return res.status(422).json({ error: 'CAPI_TOKEN_NOT_FOUND' });
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || req.ip;
    const enrichedUserData = { ...userData, client_ip_address: clientIp };
    
    if (enrichedUserData.email) enrichedUserData.email = enrichedUserData.email.toLowerCase().trim();

    try {
        const result = await facebookCapi.sendEvent({ pixelId: resolvedPixelId, accessToken, eventName, eventData, userData: enrichedUserData, eventId, url, testEventCode });
        return res.json({ success: true, meta_trace_id: result.fb_trace_id });
    } catch (e) {
        if (e.message.includes('META_API_ERROR')) return res.status(502).json({ error: 'META_GATEWAY_ERROR' });
        else if (e.message.includes('INSUFFICIENT_USER_DATA')) return res.status(422).json({ error: 'INVALID_PAYLOAD' });
        else return res.status(500).json({ error: 'INTERNAL_SERVER_ERROR' });
    }
});

export default router;
