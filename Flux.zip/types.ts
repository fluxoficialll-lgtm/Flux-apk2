
export interface User {
  email: string;
  password?: string; 
  isVerified: boolean;
  isProfileCompleted: boolean;
  profile?: UserProfile;
  googleId?: string;
  paymentConfig?: PaymentProviderConfig; 
  paymentConfigs?: Record<string, PaymentProviderConfig>; // Added to support multiple providers
  notificationSettings?: NotificationSettings; 
  securitySettings?: SecuritySettings; 
  // Configuração de marketing para afiliados (Pixel/CAPI)
  marketingConfig?: MarketingConfig;
  lastSeen?: number; 
  sessions?: UserSession[];
  changeHistory?: ChangeHistory;
  referredBy?: string; // Email do afiliado que indicou este usuário
  
  // Security System
  strikes?: number;
  isBanned?: boolean;
  banReason?: string;
}

export interface MarketingConfig {
    pixelId?: string;
    pixelToken?: string;
}

export interface ReferredSeller {
    name: string;
    username: string;
    avatar?: string;
    salesCount: number;
    totalGenerated: number;
}

export interface AffiliateSale {
    id: string;
    buyerEmail: string;
    amount: number;
    commission: number;
    timestamp: number;
    sellerName: string;
}

export interface AffiliateStats {
    totalEarned: number;
    totalInvoiced: number;
    referredSellers: ReferredSeller[];
    recentSales: AffiliateSale[];
}

export interface UserSession {
    id: string;
    device: string;
    location: string;
    timestamp: number;
    isActive: boolean;
}

export interface ChangeHistory {
    usernameChanges: number[];
    nicknameChanges: number[];
}

export interface NotificationSettings {
    pauseAll: boolean;
    // Push / App
    likes: boolean;
    comments: boolean;
    followers: boolean;
    mentions: boolean;
    messages: boolean;
    groups: boolean;
    marketplace: boolean; // New
    // Email specific
    emailUpdates: boolean; // New: News/Marketing
    emailDigest: boolean; // New: Activity Summary
}

export interface SecuritySettings {
    saveLoginInfo: boolean;
}

export interface UserProfile {
  name: string; // unique, lowercase (@username)
  nickname?: string; // Display Name (Apelido) - Optional
  bio?: string;
  website?: string; // New: Link no perfil
  photoUrl?: string;
  isPrivate: boolean;
  // Required for Real Payments
  cpf?: string;
  phone?: string;
  // Suporte para salvar configurações de marketing via completeProfile
  marketingConfig?: MarketingConfig;
}

export interface PaymentProviderConfig {
    providerId: string; // 'syncpay' | 'picpay' | 'paypal' | 'mercadopago' 
    clientId?: string; 
    clientSecret?: string;
    token?: string; // For PicPay/PayPal if needed
    isConnected: boolean;
    tokenExpiresAt?: number; 
}

export interface VerificationSession {
  code: string;
  expiresAt: number; // timestamp
  attempts: number;
}

export interface LockoutState {
  attempts: number;
  blockedUntil: number | null;
}

export interface PollOption {
  text: string;
  votes: number;
}

export interface Comment {
  id: string;
  username: string;
  avatar?: string;
  text: string;
  timestamp: number;
  likes?: number; // New
  likedByMe?: boolean; // New
  replies?: Comment[]; // New
}

export interface Post {
  id: string;
  type: 'photo' | 'poll' | 'text' | 'video';
  username: string; // @handle for display
  authorEmail?: string; // Immutable identifier
  text: string;
  image?: string; // Base64 or URL (Primary/Thumbnail)
  images?: string[]; // New: Array for Carousel
  video?: string; // Base64 or URL
  avatar?: string;
  isPublic: boolean;
  isAdultContent?: boolean; // New: 18+ Content Flag
  time: string; // Display string like "Agora" or "10m"
  timestamp: number; // For sorting
  views: number;
  viewedBy?: string[]; // New: Array of user emails who viewed this
  likes: number;
  likedBy?: string[]; // New: Array of user emails who liked this
  comments: number;
  liked: boolean;
  pollOptions?: PollOption[];
  votedOptionIndex?: number | null;
  commentsList?: Comment[]; // New: Store actual comments
  title?: string; // New: For Reels/Posts title
  location?: string; // New: For Location Filtering
  relatedGroupId?: string; // New: Reference to a group attached to this post
  // Ads Fields
  isAd?: boolean;
  adCampaignId?: string; // Reference to the campaign source
  ctaText?: string;
  ctaLink?: string;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  price: number;
  category: string;
  location: string;
  description: string;
  image?: string; // Cover Image
  sellerId: string; // Email of the seller (Immutable)
  sellerName?: string; // @handle for display
  sellerAvatar?: string;
  timestamp: number;
  comments?: Comment[]; // New: Q&A Section
  // Ads Fields
  isAd?: boolean;
  adCampaignId?: string; // Reference to the campaign source
  ctaText?: string;
  ctaLink?: string;
  soldCount?: number; // New: Total Sales
  // Enhanced Media
  images?: string[]; // Up to 5 additional photos
  video?: string; // 1 video
}

export interface Story {
    id: string;
    username: string;
    userAvatar?: string;
    mediaUrl: string;
    type: 'image' | 'video';
    timestamp: number;
    viewed: boolean;
}

export interface PaginatedResponse<T> {
    data: T[];
    nextCursor?: number;
}

export interface VipMediaItem {
  url: string;
  type: 'image' | 'video';
}

export interface GroupLink {
  id: string;
  name: string; // Identifier (e.g., "Instagram Bio")
  code: string; // Unique hash
  joins: number; // Stat counter
  createdAt: number;
  maxUses?: number; // Maximum number of joins allowed
  expiresAt?: string; // Expiration date string
}

export interface GroupSettingsConfig {
    memberLimit?: number;
    onlyAdminsPost?: boolean;
    msgSlowMode?: boolean;
    msgSlowModeInterval?: number;
    approveMembers?: boolean;
    joinSlowMode?: boolean;
    joinSlowModeInterval?: number;
    forbiddenWords?: string[];
}

export interface Group {
  id: string;
  name: string;
  description: string;
  coverImage?: string; // Base64
  isVip: boolean;
  isPrivate?: boolean; // New property for Private groups
  price?: string;
  category?: string; // For marketplace consistency
  currency?: 'BRL' | 'USD' | 'EUR' | 'BTC'; // New property for Currency
  accessType?: 'lifetime' | 'temporary';
  expirationDate?: string;
  vipDoor?: {
    media?: string; // Base64 (Legacy)
    mediaType?: 'image' | 'video' | null; // (Legacy)
    mediaItems?: VipMediaItem[]; // New: Array of media
    text?: string;
    buttonText?: string; // New: Custom CTA text for sales page
  };
  lastMessage?: string; // For preview
  time?: string; // For preview
  creatorEmail?: string; // Identifies the owner of the group
  links?: GroupLink[]; // New: List of invite links
  
  // New: Membership and Settings
  members?: string[]; // Array of user emails
  pendingMembers?: string[]; // New: For private groups
  bannedUsers?: string[]; // New: Real ban system
  admins?: string[]; // New: Real admin system (besides creator)
  settings?: GroupSettingsConfig;
  status?: 'active' | 'inactive'; // New: Group status
  
  // Advanced Marketing
  pixelId?: string; // ID do Pixel do Meta
  pixelToken?: string; // Token da API de Conversões do Meta
}

// --- Backend Types ---

export interface NotificationItem {
  id: number;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'sale' | 'pending';
  subtype?: 'friend' | 'group_join' | 'group_invite';
  username: string; // Quem gerou a notificação
  time: string;
  timestamp: number;
  avatar: string;
  text?: string;
  postImage?: string;
  isFollowing?: boolean;
  recipientEmail: string; // Para quem é a notificação
  read: boolean;
}

export interface Relationship {
  followerEmail: string;
  followingUsername: string; // Using username as ID for following
  status: 'pending' | 'accepted';
}

export interface ChatMessage {
    id: number;
    text: string;
    type: 'sent' | 'received';
    contentType: 'text' | 'audio' | 'image' | 'video' | 'file';
    mediaUrl?: string; // New field for attachments
    fileName?: string; // New field for file names
    
    // New: Product Context for Marketplace Interactions
    product?: {
        id: string;
        title: string;
        price: number;
        image?: string;
    };

    timestamp: string;
    status: 'sent' | 'delivered' | 'read';
    duration?: string;
    // New fields for Groups
    senderName?: string;
    senderAvatar?: string;
    senderEmail?: string;
}

export interface ChatData {
    id: string | number;
    contactName: string;
    isBlocked: boolean;
    messages: ChatMessage[];
}

// --- Payment & Access Types ---

export interface VipAccess {
    userId: string; // Email
    groupId: string;
    status: 'active' | 'expired';
    purchaseDate: number;
    expiresAt?: number; // New: Timestamp for expiration (for recurring/temporary access)
    transactionId: string;
}

export interface SyncPayTransaction {
    identifier: string;
    pixCode: string;
    amount: number;
    status: 'pending' | 'paid' | 'expired' | 'completed' | 'withdrawal'; // Added withdrawal
    clientId: string; // Quem pagou (Email do cliente)
    ownerId: string; // Quem recebe (Email do dono do grupo)
    groupId: string;
    platformFee: number;
    ownerNet: number;
    timestamp: number;
    pixKey?: string; // For withdrawals
}

// --- Ads ---
export interface AdStats {
    views: number;
    clicks: number;
    conversions: number;
}

export interface AdCampaign {
    id: string;
    ownerEmail: string; // To link to user
    name: string;
    scheduleType: 'date' | 'continuous';
    budget: number;
    trafficObjective: string;
    pricingModel?: 'budget' | 'commission'; // NEW: Commission = Free upfront, fee on sale. Budget = Prepaid.
    creative: {
        text: string;
        mediaUrl?: string;
        mediaType?: 'image' | 'video';
    };
    campaignObjective: string; // Entrar no grupo, Comprar VIP...
    destinationType: string; // Grupo, Link, Mensagens...
    targetUrl?: string; // NEW: URL externa (Site, App)
    targetGroupId?: string; // NEW: ID do grupo para CTAs "Entrar"
    optimizationGoal: string; // Visualizações, Compras...
    placements: ('feed' | 'reels' | 'marketplace')[];
    ctaButton: string; // Comprar, Conversar...
    status: 'draft' | 'active' | 'paused' | 'ended';
    timestamp: number;
    stats?: AdStats; // Tracking
}

export enum AuthError {
  USER_NOT_FOUND = "Gmail não existe",
  WRONG_PASSWORD = "Senha incorreta",
  EMAIL_NOT_VERIFIED = "Verifique seu email",
  INVALID_FORMAT = "Formato inválido",
  ALREADY_EXISTS = "Email já cadastrado",
  PASSWORD_TOO_SHORT = "Senha muito curta",
  PASSWORDS_DONT_MATCH = "Senhas não coincidem",
  TERMS_REQUIRED = "Aceite os termos",
  CODE_INVALID = "Código incorreto",
  CODE_EXPIRED = "Código expirado",
  TOO_MANY_ATTEMPTS = "Muitas tentativas. Bloqueado por 24h.",
  NAME_TAKEN = "Nome indisponível",
  NAME_REQUIRED = "Nome obrigatório",
  GENERIC = "Ocorreu um erro",
  ACCOUNT_BANNED = "🚫 CONTA BANIDA: Violação dos Termos"
}

export interface ModelConfig {
  id: string;
  name: string;
  description: string;
  modelName: string;
  supportsSearch: boolean;
  supportsImages: boolean;
}
